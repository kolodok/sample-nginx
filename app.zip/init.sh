#!/bin/sh

wget -O /code/index.php https://raw.githubusercontent.com/do-community/php-kubernetes/master/index.php